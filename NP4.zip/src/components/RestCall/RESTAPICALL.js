import $ from 'jquery';

const obj = {};
obj.GetDetails= (title) =>
{
  let siteUrl = "https://gohelmahendrak.sharepoint.com/sites/bestpractice/_api/web/lists/getbytitle('Page Details')/Items?$select=Banner,Description,Page_x0020_Title/Title&$expand=Page_x0020_Title/Title&$filter=Page_x0020_Title/Title eq '"+title+"'";

 return $.ajax({
   url: siteUrl,
    method: 'GET',
    headers: {'Accept': 'application/json; odata=nometadata'}
 }).then(result=>result)
 .catch(function(error) {
   return error;
     // This is where you run code if the server returns any errors
 });
}
obj.GetParameterByName= (name) =>
{
  name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
  let regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
          results = regex.exec(location.search);
  return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
obj.GetLinks = (title,type) =>
{
  let siteUrl = "https://gohelmahendrak.sharepoint.com/sites/bestpractice/_api/web/lists/getbytitle('RightNavigationLinks')/Items?$select=Title,Link,LinkType,Parent/Title&$expand=Parent/Title&$filter=(Parent/Title eq '"+title+"') and (LinkType eq '"+type+"')";

   return $.ajax({
     url: siteUrl,
      method: 'GET',
      headers: {'Accept': 'application/json; odata=nometadata'}
   }).then(result=>result)
   .catch(function(error) {
     return error;
       // This is where you run code if the server returns any errors
   });
}
obj.GetAccordianDetails = (title) =>
{
  let siteUrl = "https://gohelmahendrak.sharepoint.com/sites/bestpractice/_api/web/lists/getbytitle('Accordion')/Items?$select=Title,Description,Parent/Title&$expand=Parent/Title&$filter=Parent/Title eq '"+title+"'";

   return $.ajax({
     url: siteUrl,
      method: 'GET',
      headers: {'Accept': 'application/json; odata=nometadata'}
   }).then(result=>result)
   .catch(function(error) {
     return error;
       // This is where you run code if the server returns any errors
   });
}

export default obj;
