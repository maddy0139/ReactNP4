import React from 'react';
import ReactDOM from 'react-dom';
import obj from '../RestCall/RESTAPICALL';

class home extends React.Component
{
  render()
  {
    return(
      <div className="contents marginbot">
      	<div id="content1" className="tabscontent">
      		<div id="div_Menus_1 ">
      			<div className="tabdevider">
      				<div className="leftinfo">
      					<h4><a href="/sites/np4/SitePages/General%20Requirements.aspx">General Requirements</a></h4>
      					<ul>
      						<li><a href="/sites/np4/SitePages/General%20Requirements.aspx?l=link1">Events</a></li>
      					</ul>
      					<h4><a href="/sites/np4/SitePages/Promotional%20Events.aspx">Promotional Events</a></h4>
      					<ul>
      						<li><a href="/sites/np4/SitePages/Promotional%20Events.aspx?l=link1">Promotional Information at Events</a></li>
      					</ul>
      				</div>
      			</div>
      		</div>
      	</div>
      </div>
    );
  }
}

export default home;
