import React from 'react';
import ReactDOM from 'react-dom';

class Banner extends React.Component
{
    render()
    {
        return(
            <div>
                <img style={{width:'845px'}}src={this.props.bannerSrc}/>
            </div>
        );
    }
}

export default Banner;