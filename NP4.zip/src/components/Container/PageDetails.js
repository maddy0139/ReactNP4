import React from 'react';
import obj from '../RestCall/RESTAPICALL';

class PageDetails extends React.Component
{
    render(){
        return(
            <div>  
                <h5>{this.props.title}</h5>
                <p>{this.props.details}</p>
            </div>
          );
    }
}

export default PageDetails;