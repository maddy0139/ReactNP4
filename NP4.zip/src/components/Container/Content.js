import React from 'react';
import ReactDOM from 'react-dom';
import Banner from './Banner';
import PageDetails from './PageDetails';
import obj from '../RestCall/RESTAPICALL';
import Accordian from './Accordian';
import RightNavigation from '../Right Navigation/RightNavigation';
import $ from 'jquery';

class Content extends React.Component
{
    constructor(props){
        super(props);
        this.state = {
            bannerSrc: '',
            title: '',
            details: ''
        };

    this.collapseAll = this.collapseAll.bind(this);
    this.expandAll = this.expandAll.bind(this);

    }
    componentDidMount()
    {
        let title = obj.GetParameterByName('Page');

        obj.GetDetails(title).then(data =>{
			if(data.value.length > 0)
			{
                this.setState({bannerSrc:data.value[0].Banner.Url});
                this.setState({title:data.value[0].Page_x0020_Title.Title});
                this.setState({details:data.value[0].Description})

			}
		});
    }
    collapseAll()
    {
        $( ".Collapsible__contentOuter" ).css("height","0px");
        $( ".Collapsible__trigger" ).removeClass( "is-open" );
        $( ".Collapsible__trigger" ).addClass( "is-close" );
    }
    expandAll()
    {
        $( ".Collapsible__contentOuter" ).css("height","auto");
        $( ".Collapsible__trigger" ).removeClass( "is-close" );
        $( ".Collapsible__trigger" ).addClass( "is-open" );
    }
    render()
    {
        return(
        <div>
            <div id="content" style={{height: 'auto',width:'845px',float:'left',marginLeft: '135px'}}>
                <div className="innerwrapperpage">
                    <div className="np4container">
                        <Banner bannerSrc={this.state.bannerSrc}/>
                    </div>
                    <div className="welcomenp">
                        <PageDetails title={this.state.title} details={this.state.details}/>
                    </div>
                    <div className="innercontain">
                        <div className="expandcollaspe">
                            <a href="#" onClick={this.collapseAll.bind()}>Collapse All</a> | <a href="#" onClick={this.expandAll.bind()}>Expand All</a>
                        </div>
                        <Accordian />
                    </div>
                </div>
            </div>
            <RightNavigation/>
        </div>
        );
    }
}
export default Content;

ReactDOM.render(<Content />, document.getElementById("container"));
