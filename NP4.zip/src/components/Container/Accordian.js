import React from 'react';
import obj from '../RestCall/RESTAPICALL';
import Collapsible from 'react-collapsible';
import FadeIn from 'react-fade-in';


class Accordian extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state = {
            accordianDetails:[],
            loading: true
        };
    }
    componentDidMount()
    {
        let title = obj.GetParameterByName('Page');
        obj.GetAccordianDetails(title).then(data =>{
            if(data.value.length > 0)
            {
                this.SetAccordianDetails(data.value);
            }
        });
        
    }
    SetAccordianDetails(data)
    {
        var reactHandler = this;
		reactHandler.state.accordianDetails.splice(0);

		for(let i=0;i<data.length;i++)
		{
			var arrayvar = reactHandler.state.accordianDetails.slice();
			arrayvar.push({"title": data[i].Title,"description":data[i].Description});
			reactHandler.setState({accordianDetails: arrayvar });
        }
        reactHandler.setState({loading:false});
    }
    render()
    {
        return(
            
        <div style={{marginTop: "20px"}}>
            {this.state.loading == true &&
                <div>
                </div>
            }
            {this.state.loading != true &&
                <div>
                
                    <FadeIn>
                    {this.state.accordianDetails.map(function(item,key)
                        {
                            return (
                            <Collapsible trigger={item.title} key={key}>
                                <p 
                                                    dangerouslySetInnerHTML={{
                                                        __html: item.description
                                                    }}/>    
                            </Collapsible>
                            );
                        },this)
                    }
                    </FadeIn>
                </div>
            }
            
            
        </div>
        );
    }
}
export default Accordian;