import React from 'react';
import obj from '../RestCall/RESTAPICALL';


class GeneralLinks extends React.Component
{
    constructor(props)
    {
        super(props)
        this.state = {
            links:[]
        };
    }
    componentDidMount()
    {
        let title = obj.GetParameterByName('Page');
        let type = 'General';
        obj.GetLinks(title,type).then(data =>{
            if(data.value.length > 0)
            {
                this.SetDidYouKnowLinks(data.value);
            }
        });

    }
    SetDidYouKnowLinks(data)
    {
        var reactHandler = this;
		reactHandler.state.links.splice(0);

		for(let i=0;i<data.length;i++)
		{
			var arrayvar = reactHandler.state.links.slice();
			arrayvar.push({"title": data[i].Title,"link":data[i].Link});
			reactHandler.setState({links: arrayvar });
		}
    }
    render()
    {
        return(
            <div className="qcklinks">
                <h2>More information and furtherresources are available onthe following sites:</h2>
                <div className="detailslink">
                {this.state.links.map(function(item,key)
                    {
                        return (
                            <p className="genlink" key={key}><a href={item.link} target="_blank">{item.title}</a></p>
                        );
                    },this)
                }
                </div>
            </div>
        );
    }
}

export default GeneralLinks;
