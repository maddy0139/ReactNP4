import React from 'react';

class NP4Principles extends React.Component
{
    render()
    {
        return(
        <div className="qcklinks">
            <h2>NP4 Principles</h2>
            <div className="detailslink">
                <p className="genlink"><a target="_blank" href="https://share.novartis.net/sites/np4/SitePages/Common%20Principles.aspx">View NP4 Principles</a></p>
            </div>
        </div>
        );
    }
}

export default NP4Principles;