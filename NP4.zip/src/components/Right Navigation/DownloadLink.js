import React from 'react';

class DownloadLink extends React.Component
{
    render()
    {
        return(
            <p>
                <a href="https://gohelmahendrak.sharepoint.com/sites/bestpractice/SiteAssets/NP4/RightBanner.png" target="_blank">
                    <img src="https://gohelmahendrak.sharepoint.com/sites/bestpractice/SiteAssets/NP4/RightBanner.png" alt="" />
                </a>
            </p>
        );
    }
}
export default DownloadLink;