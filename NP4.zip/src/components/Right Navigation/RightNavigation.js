import React from 'react';
import obj from '../RestCall/RESTAPICALL';
import DownloadLink from './DownloadLink';
import Np4Principles from './NP4Principles';
import PDFLinks from './PDFLinks';
import GeneralLinks from './GeneralLinks';

class RightNavigation extends React.Component
{
    render()
    {
        return(
            <div id="rightNav" style={{height:'100px',width:'200px',float:'right'}}>
                <div className="np4teaser">
                    <DownloadLink />
                    <Np4Principles />
                    <PDFLinks />
                    <GeneralLinks />
                </div>
            </div>
        );
    }
}

export default RightNavigation;
